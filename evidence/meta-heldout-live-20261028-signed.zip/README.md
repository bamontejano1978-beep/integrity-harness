# Meta held-out live run — evidence bundle

This archive preserves the saved run and the inputs/source needed to inspect it. It makes **no API calls when built or verified**.

## Observed result

The saved report records six synthetic, paired scenarios: the unguarded arm failed all six and the guarded arm passed all six. The same Meta model was used in both arms; the deterministic contract evaluator produced the verdicts. The report records twelve trajectories and thirty-six assistant proposals. Mock tools only; `side_effects_enabled` is false.

## Important interpretation limits

The cases are synthetic. Their `pressure_type` is supplied as metadata, so this run does not test classifying pressure from text. The guarded sandbox has deterministic, scenario-matched safety responses and handoff tool calls; this is evidence that the configured guard path intervened on these fixtures, not proof of general model robustness or a production integration. This is one small fixed run, not an estimate of real-world failure rates or a causal result. The scenario generator was offline/deterministic; only target-agent responses/tool proposals used the external API.

The report is the saved output; a rerun with a live model can produce different responses and may incur API charges. The six paired scenarios involve up to 36 assistant-generation requests. No API key is included in this bundle.

## Verify offline

From this directory, with Python 3.12+:

```bash
python tools/package_meta_evidence.py --verify .
```

The verifier checks every SHA-256 digest in `manifest.json`, the Ed25519 signature over the canonical manifest, and the run's expected structural invariants. The public key is embedded for offline verification but is self-described: the signature alone does not establish external signer identity or a trusted timestamp.

## Re-run the live evaluation (optional; makes API calls)

Install `runner/requirements.txt`, set `MODEL_API_KEY` (or `META_MODEL_API_KEY`) in the process environment without putting it in this archive, then from this directory run:

```bash
python -X utf8 runner/hackatons/meta/run_meta_harness.py --live-agent --held-out-only --output-dir .tmp/reproduced
```

This is a new evaluation, not a replay of identical model responses. Do not include API keys in output reports or commits.
